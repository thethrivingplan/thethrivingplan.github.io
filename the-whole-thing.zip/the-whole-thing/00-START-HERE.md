# THE WHOLE THING — take it, keep it, pass it on

Free. Always free. Yours to download, yours to keep, yours to re-post
anywhere, forever. Copyleft: CC BY-SA 4.0 for the writings, GPL for code,
CERN-OHL-S for hardware designs. The name "The Thriving Plan" is not
part of the grant — everything else in here is.

This bundle is the public twin of a private one. The private one carries
one man's records. This one carries the work itself, and the whole idea
of how the work survives. No names on the cover: it was built by a
collaboration of ideas from many people. The byline is **we**.

## WHAT'S INSIDE

1. **01-the-thought-process.md** — the framework an AI (or a person) can
   work by. Its own first line says it: "This is the thought process
   that this AI works on." Put it into your own AI and it will work
   the way the house's AI works.
2. **02-the-thriving-plan.md** — the living plan, whole: a world with no
   holding things over people, and the step-by-step of getting there.
3. **This file** — the survival doctrine, below.

## THE WHOLE IDEA: HOW ANYTHING STAYS AVAILABLE

There is no server that lives forever. Everything that has ever stayed
available stayed the same way: **copies outnumbered the failures.**

Availability stands on three legs:

- **Copies.** The more hands hold a thing, the more doors have to close
  before it is gone. Every download is a keeper.
- **Permission.** Copyleft means the permission can never be taken
  back. Anyone holding a copy may re-post it, anywhere, legally,
  forever — no asking, no fee. If a host dies, any keeper can stand
  the door back up the same day.
- **Findability.** Keepers' copies help when people can find them:
  stable names, public archives, many doors.

Put the three together and the math flips. Stopping a work like this
stops being an errand — closing one website — and becomes a mission to
find and destroy every copy on every hard drive, every phone, every
forgotten USB stick on Earth. Billions upon billions of them. Nobody
has that army. That is the design: not a stronger vault. **More hands.**

The honest limit, printed plainly: "always" in the absolute sense does
not exist. What exists is *cheaper to keep than to kill* — and that is
achievable, and it is what this bundle is for.

## WHAT TO DO WITH IT

- **Keep it.** On your hard drive, your phone, a USB stick in a drawer.
  You are now one of the copies.
- **Hand it to an AI.** Any capable assistant, on any device: give it
  file 01 first, then file 02, and say "work by this." The conversation
  continues from the record, wherever you plug in.
- **Pass it on.** Send it, post it, mirror it. The license already says
  yes. If you change it, say what you changed and pass the same freedom
  along.
- **Re-host it.** If every door you know closes, put the files up
  yourself. That is not a workaround. That is the system working.

## FOR WHEN IT RAINS

Accounts get blocked. Hosts fail. Companies fold. Rain is not the
tragedy — rain with no umbrella is. This bundle is the umbrella, and
everybody is allowed to carry one.
